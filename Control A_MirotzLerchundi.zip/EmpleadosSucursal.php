<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "funciones.inc"?>
</head>
<body> 
    <table class="table">
                <tr>
                    <th>Nombre empleado</th>
                    <th>Puesto</th>
                    <th>Fecha contratación</th>
                    <th>Nombre Departamento</th>
                    <th>Jefe Departamento</th>
                    <th>Ubicación</th>
                </tr>
                <?php
                    $codSucursal = $_POST['codSucursal'];
                    $empleados = f_empleadosSucursal($codSucursal);
                    foreach ($empleados as $codEmpleado => $valEmpleado) { 
                        $codDepartamento = f_idDepartamentoEmpleado($valEmpleado);
                        ?>
                        <tr>
                            <td>
                                <?php echo f_nombreApellidoEmpleado($valEmpleado); ?>
                            </td>
                            <td>
                                <?php echo f_puestoEmpleado($valEmpleado); ?>
                            </td>
                            <td>
                                <?php echo f_fechaContratacionEmpleado($valEmpleado); ?>
                            </td>
                            <td>
                                <?php echo f_nombreDepartamento($codDepartamento); ?>
                            </td>
                            <td>
                                <?php echo f_nombreJefeDepartamento($codDepartamento); ?>
                            </td>
                            <td>
                                <?php echo f_ubicacionDepartamento($codDepartamento); ?>
                            </td>
                        </tr>
                    <?php
                    }
                ?>
            </table>
</body>
</html>