<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php include "funciones.inc"?>
</head>
<body>
    <form action="EmpleadosSucursal.php" method="post">
        <select name="codSucursal" id="">
        <?php
            $sucursales = f_todosSucursales();
            foreach ($sucursales as $codSucursal => $valSucursal) { ?>
                <option value="<?php echo $codSucursal; ?>">
                    <?php echo f_nombreSucursal($codSucursal); ?>
                </option>
        <?php
            }
        ?>
        </select>
        <input type="submit" value="Mostrar empleados">
    </form>
</body> 
</html>